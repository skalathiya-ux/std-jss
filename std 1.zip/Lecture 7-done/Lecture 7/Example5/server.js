const express = require("express");
const app = express();

app.use(express.json());
app.use(express.static(".")); // to serve index.html

// -----------------------------------------
// res.send() → send text or HTML
// -----------------------------------------
app.get("/send-text", (req, res) => {
    res.send("<h2>This is text/HTML sent using res.send()</h2>");
});

// -----------------------------------------
// res.json() → send JSON data
// -----------------------------------------
app.get("/send-json", (req, res) => {
    res.json({
        message: "This is JSON sent using res.json()",
        status: "success"
    });
});

// -----------------------------------------
// res.status() → custom status code
// -----------------------------------------
app.get("/send-status", (req, res) => {
    res.status(404).json({
        error: "Resource not found",
        code: 404
    });
});

// -----------------------------------------
// res.redirect() → redirect to another URL
// -----------------------------------------
app.get("/go-to-google", (req, res) => {
    res.redirect("https://www.google.com");
});

// Start server
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
