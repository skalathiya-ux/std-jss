const express = require("express");
const app = express();

app.use(express.json()); // allow POST body as JSON
app.use(express.static("public")); // serve static frontend files

// Temporary in-memory data (resets every restart)
let students = [
    { id: 1, name: "John" },
    { id: 2, name: "Mark" },
];

// --------------------------------
// GET route (fetch all students)
// --------------------------------
app.get("/api/students", (req, res) => { localhost:3000/api/students
    res.json(students);
});



// --------------------------------
// POST route (add a new student)
// --------------------------------
app.post("/api/students", (req, res) => {
    const newStudent = {
        id: Date.now(),
        name: req.body.name
    };
    students.push(newStudent);
    res.json({ message: "Student added", student: newStudent });
});

// --------------------------------
// DELETE route (remove a student)
// --------------------------------
app.delete("/api/students/:id", (req, res) => {  
    const id = Number(req.params.id);
    students = students.filter(s => s.id !== id);
    res.json({ message: "Student deleted" });
});

// Start server
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});

