// Load students from backend (GET)
function loadStudents() {
    fetch("/api/students")
        .then(res => res.json())
        .then(data => {
            let list = document.getElementById("studentList");
            list.innerHTML = "";

            data.forEach(student => {
                let li = document.createElement("li");
                li.textContent = student.name;

                // Delete button
                let del = document.createElement("button");
                del.textContent = "Delete";
                del.style.marginLeft = "10px";
                del.onclick = () => deleteStudent(student.id);

                li.appendChild(del);
                list.appendChild(li);
            });
        });
}

// Add student (POST)
function addStudent() {
    let name = document.getElementById("nameInput").value;

    //name = carl

    fetch("/api/students", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name })

      
    })
    .then(res => res.json())
    .then(() => {
        loadStudents(); // refresh list
    });
}

// Delete student (DELETE)
function deleteStudent(id) {
    fetch(`/api/students/${id}`, { method: "DELETE" })
        .then(res => res.json())
        .then(() => {
            loadStudents(); // refresh list
        });
}
