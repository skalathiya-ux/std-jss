const express = require("express");
const app = express();

app.use(express.json()); // allow JSON in req.body
app.use(express.static("."));


// ----------------------------------------
// 1. req.params — URL Parameters
// ----------------------------------------
app.get("/user/:id", (req, res) => {
    res.json({
        type: "URL Parameter Example",
        receivedId: req.params.id,       // e.g., /user/55
        methodUsed: req.method
    });
});

// ----------------------------------------
// 2. req.query — Query Strings
// ----------------------------------------
app.get("/search", (req, res) => {
    res.json({
        type: "Query String Example",
        queryReceived: req.query,       // e.g., /search?city=Toronto&age=30
        methodUsed: req.method
    });
});

// ----------------------------------------
// 3. req.body — JSON or Form Data
// ----------------------------------------
app.post("/submit", (req, res) => {
    res.json({
        type: "Body Data Example",
        bodyReceived: req.body,        // e.g., { "name": "Ali", "age": 20 }
        methodUsed: req.method
    });
});

// ----------------------------------------
// 4. req.headers — Metadata about request
// ----------------------------------------
app.get("/checkheaders", (req, res) => {
    res.json({
        type: "Headers Example",
        headersReceived: req.headers,   // e.g., User-Agent, Authorization
        methodUsed: req.method
    });
});

// ----------------------------------------
// 5. req.method — which HTTP method is used
// ----------------------------------------
app.all("/methodtest", (req, res) => {
    res.json({
        type: "Method Example",
        methodUsed: req.method
    });
});

// ----------------------------------------
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
