const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const multer = require("multer");
const path = require("path");

const app = express();
app.use(express.json());
app.use(express.static("uploads"));  // allow images to be served
app.use(express.static("public"));        // serve index.html

// --------------------------------------------
// DATABASE SETUP
// --------------------------------------------
const db = new sqlite3.Database("db.sqlite");

// Create table (if not exists)
db.run(`
    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        image TEXT
    )
`);

// --------------------------------------------
// MULTER: FILE UPLOAD SETUP
// --------------------------------------------
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage });

// --------------------------------------------
// ADD STUDENT (TEXT + IMAGE)
// --------------------------------------------
app.post("/api/students", upload.single("photo"), (req, res) => {
    const name = req.body.name;
    const imageName = req.file.filename;

    db.run(
        `INSERT INTO students (name, image) VALUES (?, ?)`,
        [name, imageName],
        function (err) {
            if (err) return res.status(500).json({ error: err });

            res.json({
                message: "Student added successfully",
                student: { id: this.lastID, name, image: imageName }
            });
        }
    );
});

// --------------------------------------------
// GET ALL STUDENTS
// --------------------------------------------
app.get("/api/students", (req, res) => {
    db.all(`SELECT * FROM students`, [], (err, rows) => {
        if (err) return res.status(500).json({ error: err });
        res.json(rows);
    });
});

// --------------------------------------------
// START SERVER
// --------------------------------------------
app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});
